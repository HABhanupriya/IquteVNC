# androidVNC
Exported from https://code.google.com/p/android-vnc-viewer/.  

Modified to build in Android Studio.
