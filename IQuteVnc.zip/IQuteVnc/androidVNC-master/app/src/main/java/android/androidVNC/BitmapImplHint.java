package android.androidVNC;

class BitmapImplHint {
	static final long AUTO = 0L;
	static final long FULL = 1L;
	static final long TILE = 2L;
}
